package OpenHelper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

//La estructura de la bd(Tablas y metodos).

public class SQLite_OpenHelper extends SQLiteOpenHelper {     //Lo hago para conectar con  SQL
    public SQLite_OpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) { //contructor
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {         //Para crear la bd

        String query =  "create table usuarios(_ID integer primary key autoincrement, Nombre text, Mail text,Password text)";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {     //para cargar los datos dentro de la misma

    }
        public void abrir() {

            this.getWritableDatabase();
        }

        public void cerrar(){  //Permite cerrar la bd
            this.close();
        }

        public void insertarReg(String nom,String cor,String pass){ //insertar registros en la bd
            ContentValues valores = new ContentValues();
            valores.put("Nombre",nom);
            valores.put("Mail",cor);
            valores.put("Password",pass);
            this.getWritableDatabase().insert("usuarios",null,valores);

    }
    public Cursor ConsultarUsuPas(String mail, String pass){
        Cursor mcursor = null;
        mcursor = this.getReadableDatabase().query("usuarios", new String[]{"ID","Nombre","Mail","Password"},"Mail like '"+mail+"'and Password like '"+pass+"'",null,null,null,null);
        return  mcursor;
    }
    }

