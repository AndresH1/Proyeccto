package com.example.andre.pl;

import android.content.Intent;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import OpenHelper.SQLite_OpenHelper;

public class registro extends AppCompatActivity {

    Button btnGrabarusu;
    EditText txtNomUsu,txtCorreoUsu,txtContraUsu;

    SQLite_OpenHelper helper = new SQLite_OpenHelper(this,"BD1",null,1);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        btnGrabarusu = (Button)findViewById(R.id.btnRegistrarUsu);
        txtNomUsu=(EditText)findViewById(R.id.txtNomUsu);
        txtCorreoUsu=(EditText)findViewById(R.id.txtCorreoUsu);
        txtContraUsu=(EditText)findViewById(R.id.txtContraUsu);

        btnGrabarusu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                helper.abrir();
                helper.insertarReg(String.valueOf(txtNomUsu.getText()),
                                   String.valueOf(txtCorreoUsu.getText()),
                                   String.valueOf(txtContraUsu.getText()));
                helper.cerrar();

                    Toast.makeText(getApplicationContext(), "Registrado con exito", Toast.LENGTH_LONG).show();

                    Intent i = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(i);

                }
        });
    }
}
